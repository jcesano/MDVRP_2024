#include "stdafx.h"
#include "Cluster.h"



// included dependencies
#include "FrogObjectCol.h"
#include "FrogLeapController.h"
#include "Pair.h"
#include "DistanceTable.h"
#include <limits>

Cluster::Cluster(int id) :FrogObject(id)
{
	this->assignedDepotPair = NULL;
	this->nearestClusterPair = NULL;
	this->customerPairCol = new FrogObjectCol();
	this->distance_t = DistanceType::nearest;
}

Cluster::Cluster(Pair * depotPair, int id) :FrogObject(id)
{
	this->assignedDepotPair = depotPair;
	this->nearestClusterPair = NULL;
	this->customerPairCol = new FrogObjectCol();
	this->distance_t = DistanceType::nearest;
}

Cluster::~Cluster()
{
	this->customerPairCol->unReferenceFrogObjectCol();
	delete this->customerPairCol;
}

void Cluster::setDepotPair(int depotIndex, FrogLeapController * controller)
{
	this->assignedDepotPair = controller->getDepotPairByIndex(depotIndex);
}

void Cluster::addCustomer(int customerIndex, FrogLeapController * controller)
{
	Pair * customerPair = controller->getCustomerPairByIndex(customerIndex);

	this->customerPairCol->addFrogObject(customerPair);
}

FrogObjectCol * Cluster::getCustomerPairCol()
{
	return this->customerPairCol;
}

void Cluster::setCustomerPairCol(FrogObjectCol * v_pairCol)
{
	this->customerPairCol = v_pairCol;
}

float Cluster::getDistanceToCustomer(int customerIndex, FrogLeapController * controller)
{
	if(this->distance_t == DistanceType::mean)
	{
		return this->getMeanDistanceToCustomer(customerIndex, controller);
	}

	if(this->distance_t == DistanceType::nearest)
	{
		return this->getNearestDistanceToCustomer(customerIndex, controller);
	}

}

float Cluster::getMeanDistanceToCustomer(int customerIndex, FrogLeapController * controller)
{
	float currentTotalDistance = std::numeric_limits<float>::max();;

	Pair * customerPair = controller->getCustomerPairByIndex(customerIndex);

	int customerInternalId = customerPair->getId();

	int depotInternalId = this->getDepotPair()->getId();

	DistanceTable * dt = controller->getDistanceTable();

	currentTotalDistance += dt->getEdge(customerInternalId, depotInternalId);

	for (int i = 0; i < this->customerPairCol->getSize(); i++)
	{
		Pair * clusterCustomerPair = (Pair *)this->customerPairCol->getFrogObject(i);
		int clusterCustomerInternalId = clusterCustomerPair->getId();
		currentTotalDistance += dt->getEdge(customerInternalId, clusterCustomerInternalId);
	}

	// k = number of customer + 1 depot
	int k = this->customerPairCol->getSize() + 1;
	return currentTotalDistance / k;
}

float Cluster::getNearestDistanceToCustomer(int customerIndex, FrogLeapController * controller)
{	

	Pair * customerPair = controller->getCustomerPairByIndex(customerIndex);

	int customerInternalId = customerPair->getId();

	int depotInternalId = this->getDepotPair()->getId();

	DistanceTable * dt = controller->getDistanceTable();

	float minDistance = dt->getEdge(customerInternalId, depotInternalId);
	//this->nearestClusterPair = this->getDepotPair();

	for (int i = 0; i < this->customerPairCol->getSize(); i++)
	{
		Pair * clusterCustomerPair = (Pair *)this->customerPairCol->getFrogObject(i);
		int clusterCustomerInternalId = clusterCustomerPair->getId();
		float currentDistance = dt->getEdge(customerInternalId, clusterCustomerInternalId);
		if(currentDistance < minDistance)
		{
			minDistance = currentDistance;
			//this->nearestClusterPair = clusterCustomerPair;
		}
	}

	return minDistance;
}

Pair * Cluster::createClusterCopy(FrogLeapController * controller)
{
	Pair * clusterPair = new Pair(PairType::IntVsInt, this->getId());
	clusterPair->set_i_IntValue(controller->getDepotInternalId(this->getId()));

	return clusterPair;
}

int Cluster::remainingDepotCapacity()
{
	
	return this->assignedDepotPair->get_j_IntValue();
}

void Cluster::printFrogObj()
{
}

bool Cluster::isTheSame(FrogObject * fs)
{
	return (this == fs);
}

Pair * Cluster::getDepotPair()
{
	return this->assignedDepotPair;
}


