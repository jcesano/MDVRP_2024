#ifndef CLUSTER_H_   /* Include guard */
#define CLUSTER_H_

//=================================
// included dependencies
#include "FrogObject.h"

class FrogLeapController;
class FrogObject;
class FrogObjectCol;
class Pair;
class DistanceTable;

enum class DistanceType { mean, nearest, furthest};

class Cluster : public FrogObject
{	

	Pair * assignedDepotPair;
	Pair * nearestClusterPair;

	FrogObjectCol * customerPairCol;

	enum class DistanceType distance_t;

public:
	Cluster(int clusterId);
	
	Cluster(Pair * depotPair, int clusterId);
	
	virtual ~Cluster();

	Pair * getDepotPair();

	void setDepotPair(int depotIndex, FrogLeapController * controller);	

	void addCustomer(int customerIndex, FrogLeapController * controller);

	FrogObjectCol * getCustomerPairCol();

	void setCustomerPairCol(FrogObjectCol * v_pairCol);

	float getDistanceToCustomer(int customerIndex, FrogLeapController * controller);

	float getMeanDistanceToCustomer(int customerIndex, FrogLeapController * controller);

	float getNearestDistanceToCustomer(int customerIndex, FrogLeapController * controller);

	//float getDistanceToDepot(int depotIndex, FrogLeapController * controller);

	Pair * createClusterCopy(FrogLeapController * controller);

	int remainingDepotCapacity();
	

	// abstract methods
	void printFrogObj();

	bool isTheSame(FrogObject * fs);
};
#endif
